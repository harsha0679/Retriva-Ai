import { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { ChatPanel } from './components/ChatPanel';
import './index.css';

export default function App() {
  const [activeDocumentId, setActiveDocumentId] = useState<string | null>(null);

  return (
    <div style={{ 
      display: 'flex', 
      width: '100vw', 
      height: '100vh', 
      overflow: 'hidden',
      backgroundColor: 'var(--bg-primary)'
    }}>
      <Sidebar 
        activeDocumentId={activeDocumentId} 
        setActiveDocumentId={setActiveDocumentId} 
      />
      <ChatPanel 
        activeDocumentId={activeDocumentId} 
      />
    </div>
  );
}
