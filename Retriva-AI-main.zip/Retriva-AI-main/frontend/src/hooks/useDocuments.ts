import { useState, useEffect, useCallback } from 'react';
import { uploadDocument, getDocuments, deleteDocument } from '../api/documents';
import type { DocumentSummary } from '../types';

export const useDocuments = () => {
  const [documents, setDocuments] = useState<DocumentSummary[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchDocuments = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const docs = await getDocuments();
      setDocuments(docs);
    } catch (err: any) {
      setError(err.message || 'Failed to fetch documents.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchDocuments();
  }, [fetchDocuments]);

  const handleUpload = async (file: File) => {
    setIsUploading(true);
    setError(null);
    try {
      await uploadDocument(file);
      await fetchDocuments(); // Refresh list after upload
    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred during upload.');
      throw err;
    } finally {
      setIsUploading(false);
    }
  };

  const handleDelete = async (documentId: string) => {
    setError(null);
    try {
      await deleteDocument(documentId);
      await fetchDocuments(); // Refresh list after delete
    } catch (err: any) {
      setError(err.message || 'Failed to delete document.');
      throw err;
    }
  };

  return {
    documents,
    isUploading,
    isLoading,
    error,
    handleUpload,
    handleDelete,
    fetchDocuments,
  };
};
