import { useState } from 'react';
import { sendChatRequest } from '../api/chat';
import type { MemoryTurn, ChatResponse } from '../types';

export const useChat = (activeDocumentId: string | null) => {
  const [messages, setMessages] = useState<MemoryTurn[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const sendMessage = async (question: string) => {
    if (!question.trim()) return;

    // Add user message to history immediately
    const userMessage: MemoryTurn = { role: 'user', content: question };
    setMessages((prev) => [...prev, userMessage]);
    setIsTyping(true);
    setError(null);

    try {
      const response: ChatResponse = await sendChatRequest({
        question,
        document_id: activeDocumentId || undefined,
        workspace_id: 'default'
      });

      const aiMessage: MemoryTurn = {
        role: 'ai',
        content: response.answer,
        sources: response.sources
      };

      setMessages((prev) => [...prev, aiMessage]);
    } catch (err: any) {
      setError(err.message || 'Failed to get a response from the AI.');
      // Optionally add an error message to the chat
      setMessages((prev) => [...prev, { role: 'ai', content: `Error: ${err.message || 'Failed to connect.'}` }]);
    } finally {
      setIsTyping(false);
    }
  };

  const clearChat = () => {
    setMessages([]);
    setError(null);
  };

  return {
    messages,
    isTyping,
    error,
    sendMessage,
    clearChat
  };
};
