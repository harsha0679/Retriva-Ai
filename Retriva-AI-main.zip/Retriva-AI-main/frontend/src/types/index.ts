export interface ChunkMetadata {
  filename: string;
  chunk_id: string;
  upload_timestamp: string;
  document_id: string;
  workspace_id?: string;
  version?: number;
  status?: string;
  page_number?: number;
}

export interface RetrievedChunk {
  text: string;
  metadata: any;
  score: number;
  document_id?: string;
  filename?: string;
  chunk_id?: string;
  page_number?: number;
  workspace_id?: string;
  version?: number;
}

export interface RAGDebugInfo {
  request_id: string;
  retrieval_latency_ms: number;
  llm_latency_ms: number;
  total_latency_ms: number;
  chunks_retrieved: number;
  llm_provider: string;
  model_name: string;
  document_filter?: string;
  workspace_filter?: string;
}

export interface ChatRequest {
  question: string;
  session_id?: string;
  document_id?: string;
  workspace_id?: string;
}

export interface ChatResponse {
  answer: string;
  session_id: string;
  sources: RetrievedChunk[];
  total_sources: number;
  debug?: RAGDebugInfo;
}

export interface DocumentSummary {
  document_id: string;
  filename: string;
  workspace_id: string;
  version: number;
  status: string;
  chunk_count: number;
  upload_timestamp: string;
}

export interface MemoryTurn {
  role: 'user' | 'ai';
  content: string;
  sources?: RetrievedChunk[];
}
