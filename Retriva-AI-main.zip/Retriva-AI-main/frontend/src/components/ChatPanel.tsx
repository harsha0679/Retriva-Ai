import React, { useState, useRef, useEffect } from 'react';
import '../index.css';
import { useChat } from '../hooks/useChat';

interface ChatPanelProps {
  activeDocumentId: string | null;
}

export const ChatPanel: React.FC<ChatPanelProps> = ({ activeDocumentId }) => {
  const [input, setInput] = useState('');
  const { messages, isTyping, error, sendMessage, clearChat } = useChat(activeDocumentId);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  // Clear chat when active document changes
  useEffect(() => {
    clearChat();
  }, [activeDocumentId]);

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!input.trim() || isTyping) return;

    sendMessage(input);
    setInput('');
  };

  return (
    <main style={{
      flex: 1,
      height: '100vh',
      display: 'flex',
      flexDirection: 'column',
      position: 'relative',
      background: 'radial-gradient(circle at 50% -20%, rgba(59, 130, 246, 0.15), transparent 60%)'
    }}>

      {/* Header Area */}
      <header style={{
        padding: '24px 40px',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        borderBottom: '1px solid rgba(255,255,255,0.03)'
      }}>
        <div>
          <h2 style={{ fontSize: '1.25rem', fontWeight: 600, margin: 0 }}>Active Context</h2>
          <p style={{ color: activeDocumentId ? 'var(--accent-secondary)' : 'var(--accent-primary)', fontSize: '0.85rem', marginTop: '4px', fontWeight: 500 }}>
            {activeDocumentId ? 'Document Specific Search' : 'Global Knowledge Base'}
          </p>
        </div>
        <div className="glass-panel" style={{ padding: '8px 16px', borderRadius: 'var(--radius-xl)', fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
          Model: Ollama
        </div>
      </header>

      {/* Messages Area */}
      <div style={{
        flex: 1,
        overflowY: 'auto',
        padding: '40px',
        display: 'flex',
        flexDirection: 'column',
        gap: '24px'
      }}>

        {messages.length === 0 && (
          <div style={{ margin: 'auto', textAlign: 'center', color: 'var(--text-secondary)', maxWidth: '400px' }}>
            <div style={{ width: '64px', height: '64px', borderRadius: '50%', background: 'var(--glass-bg)', margin: '0 auto 16px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path></svg>
            </div>
            <h3>How can I help you?</h3>
            <p style={{ fontSize: '0.9rem', marginTop: '8px' }}>Ask a question about {activeDocumentId ? 'this document' : 'your documents'} and I will retrieve the answer.</p>
          </div>
        )}

        {messages.map((msg, idx) => (
          <div key={idx} className="animate-fade-in" style={{
            display: 'flex',
            gap: '16px',
            maxWidth: '80%',
            alignSelf: msg.role === 'user' ? 'flex-end' : 'flex-start',
            flexDirection: msg.role === 'user' ? 'row-reverse' : 'row'
          }}>
            <div style={{
              width: '36px', height: '36px', borderRadius: '50%', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', fontWeight: 'bold', fontSize: '0.8rem',
              background: msg.role === 'user' ? 'rgba(255,255,255,0.1)' : 'var(--accent-gradient)'
            }}>
              {msg.role === 'user' ? 'U' : 'AI'}
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '4px', alignItems: msg.role === 'user' ? 'flex-end' : 'flex-start' }}>
              <span style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', fontWeight: 500 }}>
                {msg.role === 'user' ? 'You' : 'KnowledgeHub'}
              </span>
              <div style={{
                padding: '16px',
                fontSize: '0.95rem', lineHeight: 1.5,
                background: msg.role === 'user' ? 'var(--accent-primary)' : 'var(--bg-secondary)',
                color: msg.role === 'user' ? 'white' : 'var(--text-primary)',
                borderRadius: msg.role === 'user' ? 'var(--radius-lg) 0 var(--radius-lg) var(--radius-lg)' : '0 var(--radius-lg) var(--radius-lg) var(--radius-lg)',
                boxShadow: msg.role === 'user' ? '0 4px 12px rgba(59, 130, 246, 0.25)' : 'none',
                border: msg.role === 'user' ? 'none' : '1px solid var(--glass-border)'
              }}>
                {msg.content}

                {/* Render Sources if available */}
                {msg.sources && msg.sources.length > 0 && (
                  <div style={{ marginTop: '16px', paddingTop: '16px', borderTop: '1px solid rgba(255,255,255,0.1)' }}>
                    <p style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', marginBottom: '8px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Sources Used</p>
                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                      {msg.sources.map((source, sIdx) => (
                        <div key={sIdx} style={{ fontSize: '0.75rem', padding: '4px 8px', background: 'rgba(255,255,255,0.05)', borderRadius: '4px', color: 'var(--text-secondary)' }}>
                          {source.filename || 'Unknown'} {source.page_number ? `(Page ${source.page_number})` : ''}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}

        {isTyping && (
          <div className="animate-fade-in" style={{ display: 'flex', gap: '16px', maxWidth: '80%' }}>
            <div style={{ width: '36px', height: '36px', borderRadius: '50%', background: 'var(--accent-gradient)', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', fontWeight: 'bold', fontSize: '0.8rem' }}>AI</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
              <span style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', fontWeight: 500 }}>KnowledgeHub</span>
              <div style={{ background: 'var(--bg-secondary)', padding: '16px', borderRadius: '0 var(--radius-lg) var(--radius-lg) var(--radius-lg)', border: '1px solid var(--glass-border)', display: 'flex', gap: '4px' }}>
                <span style={{ animation: 'fadeIn 1s infinite alternate', width: '6px', height: '6px', background: 'var(--text-secondary)', borderRadius: '50%' }} />
                <span style={{ animation: 'fadeIn 1s infinite alternate', width: '6px', height: '6px', background: 'var(--text-secondary)', borderRadius: '50%', animationDelay: '0.2s' }} />
                <span style={{ animation: 'fadeIn 1s infinite alternate', width: '6px', height: '6px', background: 'var(--text-secondary)', borderRadius: '50%', animationDelay: '0.4s' }} />
              </div>
            </div>
          </div>
        )}

        {error && (
          <div style={{ color: '#ef4444', textAlign: 'center', fontSize: '0.85rem', padding: '12px', background: 'rgba(239, 68, 68, 0.1)', borderRadius: '8px', border: '1px solid rgba(239, 68, 68, 0.2)' }}>
            {error}
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div style={{ padding: '0 40px 40px 40px' }}>
        <form onSubmit={handleSubmit} className="glass-panel" style={{
          display: 'flex',
          alignItems: 'center',
          padding: '8px 8px 8px 24px',
          borderRadius: 'var(--radius-xl)',
          background: 'rgba(26, 29, 39, 0.8)',
          boxShadow: '0 12px 40px rgba(0,0,0,0.4)',
          border: '1px solid rgba(255,255,255,0.12)'
        }}>
          <input
            type="text"
            placeholder={activeDocumentId ? "Ask about this specific document..." : "Ask a question across all your documents..."}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            disabled={isTyping}
            style={{
              flex: 1,
              background: 'transparent',
              border: 'none',
              color: 'var(--text-primary)',
              fontSize: '1rem',
              outline: 'none',
              padding: '12px 0'
            }}
          />
          <button
            type="submit"
            disabled={!input.trim() || isTyping}
            style={{
              background: input.trim() && !isTyping ? 'var(--accent-gradient)' : 'rgba(255,255,255,0.1)',
              color: input.trim() && !isTyping ? 'white' : 'var(--text-secondary)',
              border: 'none',
              borderRadius: '50%',
              width: '44px',
              height: '44px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: input.trim() && !isTyping ? 'pointer' : 'default',
              transition: 'all 0.3s ease',
              marginLeft: '12px'
            }}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <line x1="22" y1="2" x2="11" y2="13"></line>
              <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
            </svg>
          </button>
        </form>
        <p style={{ textAlign: 'center', color: 'var(--text-secondary)', fontSize: '0.75rem', marginTop: '16px' }}>
          AI can make mistakes. Consider verifying important information.
        </p>
      </div>

    </main>
  );
};
