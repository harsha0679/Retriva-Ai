import React, { useRef } from 'react';
import '../index.css';
import { useDocuments } from '../hooks/useDocuments';

interface SidebarProps {
  activeDocumentId: string | null;
  setActiveDocumentId: (id: string | null) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeDocumentId, setActiveDocumentId }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { documents, isUploading, isLoading, error, handleUpload, handleDelete } = useDocuments();

  const onUploadClick = () => {
    fileInputRef.current?.click();
  };

  const onFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      await handleUpload(file);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    } catch (e) {
      // Error handled in hook
    }
  };

  return (
    <aside style={{
      width: '320px',
      height: '100vh',
      padding: '24px',
      display: 'flex',
      flexDirection: 'column',
      gap: '24px',
      borderRight: '1px solid var(--glass-border)',
      backgroundColor: 'var(--bg-secondary)',
      transition: 'all 0.3s ease'
    }}>
      <div style={{ paddingBottom: '16px', borderBottom: '1px solid var(--glass-border)' }}>
        <h2 className="gradient-text" style={{ fontSize: '1.5rem', fontWeight: 700, margin: 0 }}>Retriva-AI</h2>
        <p style={{ color: 'var(--text-secondary)', fontSize: '0.85rem', marginTop: '4px' }}>AI Assistant</p>
      </div>

      <nav style={{ display: 'flex', flexDirection: 'column', gap: '8px', flex: 1, overflowY: 'auto' }}>
        <h3 style={{ color: 'var(--text-secondary)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '8px' }}>
          Documents context
        </h3>

        {/* Global Context (No Document Selected) */}
        <div
          onClick={() => setActiveDocumentId(null)}
          style={{
            padding: '12px 16px',
            display: 'flex',
            alignItems: 'center',
            gap: '12px',
            cursor: 'pointer',
            borderRadius: 'var(--radius-md)',
            background: activeDocumentId === null ? 'rgba(59, 130, 246, 0.1)' : 'transparent',
            border: activeDocumentId === null ? '1px solid rgba(59, 130, 246, 0.2)' : '1px solid transparent',
            transition: 'all 0.2s ease'
          }}
          onMouseEnter={(e) => { if (activeDocumentId !== null) e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.03)' }}
          onMouseLeave={(e) => { if (activeDocumentId !== null) e.currentTarget.style.backgroundColor = 'transparent' }}
        >
          <div style={{ width: '8px', height: '8px', borderRadius: '50%', backgroundColor: activeDocumentId === null ? 'var(--accent-primary)' : 'var(--text-secondary)' }} />
          <span style={{ fontSize: '0.9rem', color: activeDocumentId === null ? 'var(--text-primary)' : 'var(--text-secondary)', fontWeight: activeDocumentId === null ? 600 : 400 }}>
            Search Entire Knowledge Base
          </span>
        </div>

        <div style={{ margin: '8px 0', borderBottom: '1px solid rgba(255,255,255,0.05)' }} />

        {isLoading && documents.length === 0 && (
          <p style={{ color: 'var(--text-secondary)', fontSize: '0.85rem', textAlign: 'center' }}>Loading documents...</p>
        )}

        {documents.map((doc) => {
          const isActive = activeDocumentId === doc.document_id;
          return (
            <div
              key={doc.document_id}
              onClick={() => setActiveDocumentId(doc.document_id)}
              style={{
                padding: '12px 16px',
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                cursor: 'pointer',
                borderRadius: 'var(--radius-md)',
                background: isActive ? 'rgba(139, 92, 246, 0.1)' : 'transparent', // Purple for active doc
                border: isActive ? '1px solid rgba(139, 92, 246, 0.2)' : '1px solid transparent',
                transition: 'all 0.2s ease'
              }}
              onMouseEnter={(e) => { if (!isActive) e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.03)' }}
              onMouseLeave={(e) => { if (!isActive) e.currentTarget.style.backgroundColor = 'transparent' }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px', overflow: 'hidden' }}>
                <div style={{ width: '8px', height: '8px', borderRadius: '50%', backgroundColor: isActive ? 'var(--accent-secondary)' : 'var(--text-secondary)' }} />
                <span style={{
                  fontSize: '0.9rem',
                  color: isActive ? 'var(--text-primary)' : 'var(--text-secondary)',
                  fontWeight: isActive ? 600 : 400,
                  whiteSpace: 'nowrap',
                  overflow: 'hidden',
                  textOverflow: 'ellipsis'
                }}>
                  {doc.filename}
                </span>
              </div>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  handleDelete(doc.document_id);
                  if (isActive) setActiveDocumentId(null);
                }}
                style={{
                  background: 'transparent',
                  border: 'none',
                  color: 'var(--text-secondary)',
                  cursor: 'pointer',
                  padding: '4px',
                  display: 'flex',
                  alignItems: 'center'
                }}
                title="Delete document"
              >
                ✕
              </button>
            </div>
          );
        })}
      </nav>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
        {error && (
          <p style={{ color: '#ef4444', fontSize: '0.8rem', textAlign: 'center' }}>{error}</p>
        )}
        <input
          type="file"
          ref={fileInputRef}
          style={{ display: 'none' }}
          onChange={onFileChange}
        />
        <button
          onClick={onUploadClick}
          disabled={isUploading}
          style={{
            padding: '12px',
            borderRadius: 'var(--radius-md)',
            background: isUploading ? 'var(--bg-primary)' : 'var(--accent-gradient)',
            color: isUploading ? 'var(--text-secondary)' : 'white',
            border: isUploading ? '1px solid var(--glass-border)' : 'none',
            fontWeight: 600,
            cursor: isUploading ? 'not-allowed' : 'pointer',
            boxShadow: isUploading ? 'none' : '0 4px 14px 0 rgba(59, 130, 246, 0.39)',
            transition: 'all 0.2s ease'
          }}
          onMouseEnter={(e) => {
            if (!isUploading) e.currentTarget.style.transform = 'translateY(-2px)'
          }}
          onMouseLeave={(e) => {
            if (!isUploading) e.currentTarget.style.transform = 'translateY(0)'
          }}
        >
          {isUploading ? 'Uploading...' : '+ Upload Document'}
        </button>
      </div>
    </aside>
  );
};
