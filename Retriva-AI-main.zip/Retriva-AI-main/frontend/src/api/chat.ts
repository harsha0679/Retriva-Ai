import type { ChatRequest, ChatResponse } from '../types';

export const sendChatRequest = async (request: ChatRequest): Promise<ChatResponse> => {
  try {
    const response = await fetch('http://127.0.0.1:8080/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(request),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => null);
      throw new Error(errorData?.detail || `Chat request failed with status ${response.status}`);
    }

    return await response.json();
  } catch (error) {
    console.error('Error sending chat request:', error);
    throw error;
  }
};
