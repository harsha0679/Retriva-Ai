import type { DocumentSummary } from '../types';

export const uploadDocument = async (file: File): Promise<any> => {
  const formData = new FormData();
  formData.append('file', file);
  formData.append('workspace_id', 'default');
  formData.append('version', '1');

  try {
    const response = await fetch('http://127.0.0.1:8080/upload', {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => null);
      throw new Error(errorData?.detail || `Upload failed with status ${response.status}`);
    }

    return await response.json();
  } catch (error) {
    console.error('Error uploading document:', error);
    throw error;
  }
};

export const getDocuments = async (): Promise<DocumentSummary[]> => {
  try {
    const response = await fetch('http://127.0.0.1:8080/documents?workspace_id=default');
    
    if (!response.ok) {
      const errorData = await response.json().catch(() => null);
      throw new Error(errorData?.detail || `Failed to fetch documents with status ${response.status}`);
    }

    return await response.json();
  } catch (error) {
    console.error('Error fetching documents:', error);
    throw error;
  }
};

export const deleteDocument = async (documentId: string): Promise<any> => {
  try {
    const response = await fetch(`http://127.0.0.1:8080/documents/${documentId}`, {
      method: 'DELETE',
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => null);
      throw new Error(errorData?.detail || `Failed to delete document with status ${response.status}`);
    }

    return await response.json();
  } catch (error) {
    console.error('Error deleting document:', error);
    throw error;
  }
};
