import logging
from typing import List, Optional, Dict
from app.domain.models import RetrievedChunk
from app.infrastructure.embeddings.factory import EmbeddingFactory
from app.infrastructure.vector_db.factory import VectorDBFactory
from app.infrastructure.retrieval.bm25_provider import BM25Retriever
from app.core.config import settings

logger = logging.getLogger(__name__)

# BM25 minimum score — set to 0.0 so BM25 always contributes candidates.
# RRF ranking naturally de-weights low-scoring BM25 matches; hard thresholding
# here is too aggressive for short/typo queries.
BM25_MIN_SCORE = 0.0


class RetrievalService:
    """
    Hybrid Retrieval Engine: Dense Vector Search (ChromaDB) +
    Sparse Keyword Search (BM25) fused via Reciprocal Rank Fusion (RRF).

    Optimizations:
    - Lazy BM25 index: rebuilt only when the stored chunk count changes.
    - BM25 minimum score threshold to cut noise before RRF.
    - Document-scoped fallback (threshold=0.0) ensures scoped queries never
      return empty when vector similarity is below threshold.
    """

    def __init__(self):
        self.embedding_provider = EmbeddingFactory.get_provider()
        self.vector_db_provider = VectorDBFactory.get_provider()
        self.bm25_retriever = BM25Retriever()
        
        try:
            from fastembed import TextRerank
            self.reranker = TextRerank(model_name="BAAI/bge-reranker-base")
            logger.info("TextRerank model initialized: BAAI/bge-reranker-base")
        except Exception as e:
            logger.warning(f"Failed to initialize reranker: {e}")
            self.reranker = None
            
        # Build initial index (may be empty on fresh start)
        self._rebuild_bm25_index()
        logger.info("RetrievalService initialized with Hybrid (Vector + BM25) search.")

    # ─────────────────────────────────────────────────────────────
    # BM25 Index Management
    # ─────────────────────────────────────────────────────────────

    def _rebuild_bm25_index(self):
        """
        Always rebuild the BM25 index from the current ChromaDB state.
        Called at init and at the start of every retrieve().
        Cost is ~1-5ms for typical document sets — acceptable overhead
        that guarantees the index is never stale after delete/re-ingest.
        """
        try:
            if not hasattr(self.vector_db_provider, 'get_all_chunks'):
                return
            all_chunks = self.vector_db_provider.get_all_chunks()
            self.bm25_retriever.index(all_chunks)
            logger.info(f"BM25 index rebuilt: {len(all_chunks)} chunks from ChromaDB.")
        except Exception as e:
            logger.warning(f"Could not rebuild BM25 index: {e}")

    # ─────────────────────────────────────────────────────────────
    # Main Retrieval
    # ─────────────────────────────────────────────────────────────

    def retrieve(
        self,
        question: str,
        document_id: Optional[str] = None,
        workspace_id: Optional[str] = None,
        threshold: Optional[float] = None,
    ) -> List[RetrievedChunk]:
        """
        Hybrid Search:
        1. Vector Search (ChromaDB dense embeddings)
        2. BM25 Keyword Search (fuzzy typo-corrected)
        3. Reciprocal Rank Fusion (RRF)
        """
        # Always rebuild BM25 from current DB state to avoid stale-index issues
        self._rebuild_bm25_index()

        top_k = settings.TOP_K
        clean_question = question.strip()

        # Compute typo-corrected version using BM25 corpus vocabulary
        # This is passed to the LLM so it sees clean text, not raw typos
        self.last_normalized_question = self.bm25_retriever.normalize_query(clean_question)

        # Effective similarity threshold
        if threshold is not None:
            effective_threshold = threshold
        elif document_id:
            # Relaxed threshold for document-scoped queries
            effective_threshold = min(settings.SIMILARITY_THRESHOLD, 0.15)
        else:
            effective_threshold = settings.SIMILARITY_THRESHOLD

        logger.info(
            f"Hybrid Search: '{clean_question[:70]}' "
            f"| doc={document_id} | threshold={effective_threshold}"
        )

        # ── 1. Vector Search ─────────────────────────────────────
        query_emb = self.embedding_provider.embed_documents([clean_question])[0]
        vector_chunks = self.vector_db_provider.search(
            query_embedding=query_emb,
            top_k=top_k * 2,
            document_id=document_id,
            workspace_id=workspace_id,
            threshold=effective_threshold,
        )

        # ── 2. BM25 Keyword Search ────────────────────────────────
        # For document-scoped queries use no minimum score floor, so BM25
        # always provides candidates from the target document even on typos.
        bm25_min = 0.0 if document_id else BM25_MIN_SCORE
        bm25_chunks = self.bm25_retriever.search(
            query=clean_question,
            top_k=top_k * 2,
            document_id=document_id,
            workspace_id=workspace_id,
            min_score=bm25_min,
        )

        # ── 3. Handle empty cases ─────────────────────────────────
        if not vector_chunks and not bm25_chunks:
            if document_id:
                # Scoped fallback: return best-matching chunks from doc ignoring threshold
                logger.info(f"Scoped fallback: no chunks above threshold for doc={document_id}.")
                fallback = self.vector_db_provider.search(
                    query_embedding=query_emb,
                    top_k=top_k,
                    document_id=document_id,
                    workspace_id=workspace_id,
                    threshold=0.0,
                )
                return fallback[:top_k]
            logger.info("Hybrid Search: No chunks returned from either retriever.")
            return []

        if not bm25_chunks:
            logger.info(f"Hybrid Search: Vector-only. Returning {min(len(vector_chunks), top_k)} chunks.")
            return vector_chunks[:top_k]

        if not vector_chunks:
            logger.info(f"Hybrid Search: BM25-only. Returning {min(len(bm25_chunks), top_k)} chunks.")
            return bm25_chunks[:top_k]

        # ── 4. Reciprocal Rank Fusion ─────────────────────────────
        fused = self._reciprocal_rank_fusion(vector_chunks, bm25_chunks, top_k=top_k)
        logger.info(f"Hybrid RRF: fused {len(fused)} chunks from {len(vector_chunks)} vector + {len(bm25_chunks)} BM25.")
        
        # ── 5. Cross-Encoder Re-Ranking ───────────────────────────
        if self.reranker and fused:
            try:
                # We need to extract the text from the fused chunks
                documents = [chunk.text for chunk in fused]
                rerank_k = getattr(settings, "RERANK_TOP_K", 5)
                
                # Perform re-ranking
                results = list(self.reranker.rerank(clean_question, documents))
                
                # The reranker returns results as objects with `.corpus_id` and `.score`
                # Sort the results by score descending (it should already be sorted)
                results.sort(key=lambda x: x.score, reverse=True)
                
                reranked_chunks = []
                for result in results[:rerank_k]:
                    original_chunk = fused[result.corpus_id]
                    # Update score to reranker score
                    original_chunk.score = float(result.score)
                    reranked_chunks.append(original_chunk)
                    
                logger.info(f"Re-Ranking: kept top {len(reranked_chunks)} chunks.")
                return reranked_chunks
            except Exception as e:
                logger.error(f"Re-ranking failed, falling back to RRF: {e}")
                
        return fused[:getattr(settings, "RERANK_TOP_K", 5)]

    # ─────────────────────────────────────────────────────────────
    # Reciprocal Rank Fusion
    # ─────────────────────────────────────────────────────────────

    def _reciprocal_rank_fusion(
        self,
        vector_chunks: List[RetrievedChunk],
        bm25_chunks: List[RetrievedChunk],
        k: int = 60,
        top_k: int = 7,
    ) -> List[RetrievedChunk]:
        """
        RRF score = 1/(k + rank_vector) + 1/(k + rank_bm25)
        k=60 is the standard constant from the original RRF paper (Cormack et al. 2009).
        """
        rrf_scores: Dict[str, float] = {}
        chunk_map: Dict[str, RetrievedChunk] = {}

        for rank, chunk in enumerate(vector_chunks, start=1):
            key = chunk.chunk_id or chunk.text[:64]
            chunk_map[key] = chunk
            rrf_scores[key] = rrf_scores.get(key, 0.0) + (1.0 / (k + rank))

        for rank, chunk in enumerate(bm25_chunks, start=1):
            key = chunk.chunk_id or chunk.text[:64]
            if key not in chunk_map:
                chunk_map[key] = chunk
            rrf_scores[key] = rrf_scores.get(key, 0.0) + (1.0 / (k + rank))

        sorted_keys = sorted(rrf_scores, key=lambda c: rrf_scores[c], reverse=True)

        results = []
        for key in sorted_keys[:top_k]:
            chunk = chunk_map[key]
            chunk.score = round(rrf_scores[key], 5)
            results.append(chunk)

        return results
