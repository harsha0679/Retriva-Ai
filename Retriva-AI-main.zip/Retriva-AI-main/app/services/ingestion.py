import uuid
from datetime import datetime, timezone
from app.infrastructure.document_loaders.loader import SimpleDocumentLoader
from app.infrastructure.chunkers.text_chunker import SimpleTextChunker
from app.infrastructure.embeddings.factory import EmbeddingFactory
from app.infrastructure.vector_db.factory import VectorDBFactory
from app.core.config import settings

class KnowledgeIngestionService:
    """
    Orchestrates the Knowledge Ingestion Pipeline.
    Phase 2.5 Enhancements: Supports workspace_id, version, and status metadata tagging.
    """
    def __init__(self):
        self.loader = SimpleDocumentLoader()
        self.chunker = SimpleTextChunker()
        self.embedding_provider = EmbeddingFactory.get_provider()
        self.vector_db_provider = VectorDBFactory.get_provider()

    def process_file(
        self,
        file_content: bytes,
        filename: str,
        workspace_id: str = "default",
        version: int = 1
    ) -> dict:
        """
        Flow:
        1. Extract Text
        2. Chunk Text (attaching document_id, workspace_id, version, status)
        3. Generate Embeddings
        4. Store in Vector DB
        """
        document_id = str(uuid.uuid4())
        upload_timestamp = datetime.now(timezone.utc).isoformat()

        # 1. Extract Text & Pages
        pages = self.loader.load_pages(file_content, filename)

        # 2. Chunk Text with page-level metadata
        if hasattr(self.chunker, 'chunk_pages'):
            chunks = self.chunker.chunk_pages(
                pages=pages,
                filename=filename,
                document_id=document_id,
                upload_timestamp=upload_timestamp,
                workspace_id=workspace_id,
                version=version,
                status="active"
            )
        else:
            extracted_text = self.loader.load(file_content, filename)
            chunks = self.chunker.chunk(
                text=extracted_text,
                filename=filename,
                document_id=document_id,
                upload_timestamp=upload_timestamp,
                workspace_id=workspace_id,
                version=version,
                status="active"
            )

        if not chunks:
            return {
                "status": "error",
                "document_id": document_id,
                "filename": filename,
                "total_chunks": 0,
                "workspace_id": workspace_id,
                "version": version,
                "message": "No text could be extracted or chunked from the file."
            }

        # 3. Generate Embeddings
        chunk_texts = [c.text for c in chunks]
        embeddings = self.embedding_provider.embed_documents(chunk_texts)

        # 4. Store in Vector DB
        self.vector_db_provider.store(chunks=chunks, embeddings=embeddings)

        return {
            "status": "success",
            "document_id": document_id,
            "filename": filename,
            "total_chunks": len(chunks),
            "workspace_id": workspace_id,
            "version": version,
            "message": "File processed and stored successfully."
        }
