import time
import uuid
import logging
from app.domain.models import ChatRequest, ChatResponse, RAGDebugInfo
from app.services.retrieval import RetrievalService
from app.services.prompt_builder import PromptBuilder
from app.services.generation import GenerationService
from app.infrastructure.memory.factory import MemoryFactory
from app.core.config import settings

logger = logging.getLogger(__name__)

FALLBACK_NO_INFO_MESSAGE = "I couldn't find enough relevant information in the available documents."

class ChatService:
    """
    Main RAG pipeline orchestrator with Phase 3 observability.
    Captures retrieval latency, LLM latency, chunk count, and provider info per request.
    """
    def __init__(self):
        self.retrieval_service = RetrievalService()
        self.prompt_builder = PromptBuilder()
        self.generation_service = GenerationService()
        self.memory = MemoryFactory.get_provider()
        logger.info("ChatService initialized.")

    def _rewrite_query(self, raw_query: str) -> str:
        """
        Query Expansion: Ask the LLM to rewrite a potentially messy user query
        into a clean, formal search query for better vector retrieval.
        """
        # If the query is already very long, don't rewrite it to avoid losing intent
        if len(raw_query.split()) > 20:
            return raw_query
            
        prompt = (
            "You are a search query optimization assistant.\n"
            "Rewrite the following user query into a clean, formal business query for a database search.\n"
            "Only output the rewritten query. Do not add any explanations or quotes.\n\n"
            f"User Query: {raw_query}\n"
            "Rewritten Query:"
        )
        try:
            from app.infrastructure.llm.factory import LLMFactory
            llm = LLMFactory.get_provider()
            rewritten = llm.generate(prompt).strip(' \n"')
            logger.info(f"Query Expansion: '{raw_query}' -> '{rewritten}'")
            return rewritten if rewritten else raw_query
        except Exception as e:
            logger.warning(f"Query expansion failed: {e}")
            return raw_query

    def chat(self, request: ChatRequest) -> ChatResponse:
        request_id = str(uuid.uuid4())
        t_start = time.perf_counter()

        logger.info(
            f"[req={request_id}] [session={request.session_id}] "
            f"question='{request.question[:80]}' doc_id={request.document_id} workspace={request.workspace_id}"
        )

        history = self.memory.get_history(request.session_id)

        # ── Query Expansion ───────────────────────────────────────────────────
        search_query = self._rewrite_query(request.question)

        # ── Retrieval (timed) ─────────────────────────────────────────────────
        t_retrieval_start = time.perf_counter()
        retrieved_chunks = self.retrieval_service.retrieve(
            question=search_query,
            document_id=request.document_id,
            workspace_id=request.workspace_id
        )
        retrieval_latency_ms = round((time.perf_counter() - t_retrieval_start) * 1000, 2)

        # ── Fallback: no chunks passed threshold ───────────────────────────────
        if not retrieved_chunks:
            total_latency_ms = round((time.perf_counter() - t_start) * 1000, 2)
            logger.info(f"[req={request_id}] No chunks passed threshold. Returning fallback.")
            self.memory.add_turn(request.session_id, request.question, FALLBACK_NO_INFO_MESSAGE)
            return ChatResponse(
                answer=FALLBACK_NO_INFO_MESSAGE,
                session_id=request.session_id,
                sources=[],
                total_sources=0,
                debug=RAGDebugInfo(
                    request_id=request_id,
                    retrieval_latency_ms=retrieval_latency_ms,
                    llm_latency_ms=0.0,
                    total_latency_ms=total_latency_ms,
                    chunks_retrieved=0,
                    llm_provider=settings.LLM_PROVIDER,
                    model_name=settings.LLM_MODEL,
                    document_filter=request.document_id,
                    workspace_filter=request.workspace_id
                )
            )

        # ── Generation (timed) ────────────────────────────────────────────────
        # Use typo-corrected question so the LLM sees clean text
        normalized_question = getattr(
            self.retrieval_service, 'last_normalized_question', request.question
        )
        prompt = self.prompt_builder.build(
            question=request.question,
            normalized_question=normalized_question,
            retrieved_chunks=retrieved_chunks,
            history=history
        )
        t_llm_start = time.perf_counter()
        answer = self.generation_service.generate(prompt)
        llm_latency_ms = round((time.perf_counter() - t_llm_start) * 1000, 2)

        total_latency_ms = round((time.perf_counter() - t_start) * 1000, 2)
        logger.info(
            f"[req={request_id}] Done. retrieval={retrieval_latency_ms}ms "
            f"llm={llm_latency_ms}ms total={total_latency_ms}ms chunks={len(retrieved_chunks)}"
        )

        self.memory.add_turn(request.session_id, request.question, answer)

        return ChatResponse(
            answer=answer,
            session_id=request.session_id,
            sources=retrieved_chunks,
            total_sources=len(retrieved_chunks),
            debug=RAGDebugInfo(
                request_id=request_id,
                retrieval_latency_ms=retrieval_latency_ms,
                llm_latency_ms=llm_latency_ms,
                total_latency_ms=total_latency_ms,
                chunks_retrieved=len(retrieved_chunks),
                llm_provider=settings.LLM_PROVIDER,
                model_name=settings.LLM_MODEL,
                document_filter=request.document_id,
                workspace_filter=request.workspace_id
            )
        )
