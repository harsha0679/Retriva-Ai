from typing import List, Optional
from app.domain.models import RetrievedChunk, MemoryTurn


class PromptBuilder:
    """
    Assembles a high-signal, low-noise prompt optimised for instruction-tuned
    models (like Qwen 2.5 7B with 128K context support via Ollama).

    Key design: accepts both the raw user question AND a BM25 vocabulary-corrected
    normalized version. The LLM always sees the cleaned question so typos like
    'expireance' never confuse it — without losing any retrieval signal.
    """

    def build(
        self,
        question: str,
        retrieved_chunks: List[RetrievedChunk],
        history: List[MemoryTurn],
        normalized_question: Optional[str] = None,
    ) -> str:
        # Use normalized (typo-corrected) question for the LLM if available
        llm_question = normalized_question if normalized_question else question

        # ── System instruction (concise for small models) ────────────────────
        system_block = (
            "You are a precise document Q&A assistant.\n"
            "Rules:\n"
            "1. Answer using information in the <context> below.\n"
            "2. You may infer obvious contextual details (like the name of the company, author, or document subject) from headers, titles, and introductions found in the context.\n"
            "3. Be direct. State the answer in the first sentence.\n"
            "4. Quote numbers, names, and dates exactly as they appear in the context.\n"
            "5. If the context genuinely has NO related information at all, say: "
            "'The document does not contain information about this topic.'\n"
            "6. Do NOT speculate or add external knowledge outside of reasonable contextual deduction."
        )

        # ── Conversation history (Qwen 2.5 can handle long contexts) ────────
        history_block = ""
        if history:
            lines = ["<history>"]
            for turn in history[-10:]:
                lines.append(f"User: {turn.question}")
                lines.append(f"Assistant: {turn.answer}")
            lines.append("</history>")
            history_block = "\n".join(lines)

        # ── Context block — most-relevant chunk first ─────────────────────────
        if retrieved_chunks:
            sorted_chunks = sorted(
                retrieved_chunks, key=lambda c: c.score or 0.0, reverse=True
            )
            context_lines = ["<context>"]
            for i, chunk in enumerate(sorted_chunks, start=1):
                filename = chunk.filename or chunk.metadata.get("filename", "Unknown")
                page_num = chunk.page_number or chunk.metadata.get("page_number")
                page_info = f" | Page {page_num}" if page_num else ""
                context_lines.append(
                    f"[Source {i}: {filename}{page_info}]\n{chunk.text.strip()}"
                )
            context_lines.append("</context>")
            context_block = "\n\n".join(context_lines)
        else:
            context_block = (
                "<context>\nNo relevant information found in the uploaded documents.\n</context>"
            )

        # ── Final prompt assembly ─────────────────────────────────────────────
        parts = [system_block]
        if history_block:
            parts.append(history_block)
        parts.append(context_block)
        parts.append(f"<question>{llm_question}</question>")
        parts.append("Answer:")

        return "\n\n".join(parts)
