import logging
from app.domain.ports import LLMProviderPort
from app.infrastructure.llm.factory import LLMFactory

logger = logging.getLogger(__name__)

class GenerationService:
    """
    Responsible ONLY for sending a prompt to the LLM and returning the response.

    Why it exists: To decouple "sending to the LLM" from all other concerns.
    What problem it solves: The ChatService builds the prompt and orchestrates the flow,
      but it never interacts directly with an LLM SDK. That detail is hidden here.
    Why we separated it: If we want to add retry logic, token counting, logging, 
      or streaming later, we only change this file — nothing else.
    Streaming-ready: To support streaming in the future, simply add a 
      `generate_stream()` method here that yields chunks, matching a new method 
      on LLMProviderPort.

    Flow:
        prompt (str) → LLMFactory → LLMProvider.generate() → answer (str)
    """
    def __init__(self):
        self.llm_provider: LLMProviderPort = LLMFactory.get_provider()
        logger.info("GenerationService initialized.")

    def generate(self, prompt: str) -> str:
        """
        Send a built prompt to the configured LLM and return the answer text.

        Args:
            prompt: The fully assembled prompt string from PromptBuilder.

        Returns:
            The LLM's generated answer as a plain string.
        """
        logger.info("Sending prompt to LLM for generation...")
        answer = self.llm_provider.generate(prompt)
        logger.info("Generation complete.")
        return answer
