import logging
from typing import List, Optional
from app.domain.models import DocumentSummary, DeleteDocumentResponse, DeleteAllResponse
from app.infrastructure.vector_db.factory import VectorDBFactory

logger = logging.getLogger(__name__)

class DocumentService:
    """Service for document management: listing, single-delete, and delete-all."""
    def __init__(self):
        self.vector_db_provider = VectorDBFactory.get_provider()

    def list_documents(self, workspace_id: Optional[str] = None) -> List[DocumentSummary]:
        return self.vector_db_provider.list_documents(workspace_id=workspace_id)

    def delete_document(self, document_id: str) -> DeleteDocumentResponse:
        deleted_count = self.vector_db_provider.delete_document(document_id=document_id)
        if deleted_count == 0:
            return DeleteDocumentResponse(
                status="not_found", document_id=document_id, deleted_chunks=0,
                message=f"No chunks found for document_id '{document_id}'."
            )
        return DeleteDocumentResponse(
            status="success", document_id=document_id, deleted_chunks=deleted_count,
            message=f"Deleted document '{document_id}' ({deleted_count} chunks removed)."
        )

    def delete_all(self) -> DeleteAllResponse:
        """Delete ALL documents from the vector database."""
        result = self.vector_db_provider.delete_all()
        docs = result.get("documents", 0)
        chunks = result.get("chunks", 0)
        logger.warning(f"DELETE ALL executed: {docs} documents, {chunks} chunks removed.")
        return DeleteAllResponse(
            status="success",
            deleted_documents=docs,
            deleted_chunks=chunks,
            message=f"Deleted all {docs} documents ({chunks} total chunks removed)."
        )
