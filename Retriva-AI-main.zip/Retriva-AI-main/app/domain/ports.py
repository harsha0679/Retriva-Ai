from abc import ABC, abstractmethod
from typing import List, Optional, Tuple
from app.domain.models import TextChunk, RetrievedChunk, MemoryTurn, DocumentSummary

# ── Phase 1 Ports ─────────────────────────────────────────────────────────────

class DocumentLoaderPort(ABC):
    @abstractmethod
    def load(self, file_content: bytes, filename: str) -> str:
        pass

    @abstractmethod
    def load_pages(self, file_content: bytes, filename: str) -> List[Tuple[str, Optional[int]]]:
        """Returns a list of (page_text, page_number) tuples."""
        pass

class TextChunkerPort(ABC):
    @abstractmethod
    def chunk(
        self, text: str, filename: str, document_id: str, upload_timestamp: str,
        workspace_id: str = "default", version: int = 1, status: str = "active"
    ) -> List[TextChunk]:
        pass

class EmbeddingProviderPort(ABC):
    @abstractmethod
    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        pass

class VectorDBProviderPort(ABC):
    @abstractmethod
    def store(self, chunks: List[TextChunk], embeddings: List[List[float]]):
        pass

    @abstractmethod
    def search(
        self, query_embedding: List[float], top_k: int,
        document_id: Optional[str] = None, workspace_id: Optional[str] = None,
        threshold: Optional[float] = None
    ) -> List[RetrievedChunk]:
        pass

    @abstractmethod
    def delete_document(self, document_id: str) -> int:
        pass

    @abstractmethod
    def delete_all(self) -> dict:
        """Delete ALL documents from the vector database. Returns {'documents': int, 'chunks': int}."""
        pass

    @abstractmethod
    def list_documents(self, workspace_id: Optional[str] = None) -> List[DocumentSummary]:
        pass

# ── Phase 2 Ports ─────────────────────────────────────────────────────────────

class LLMProviderPort(ABC):
    @abstractmethod
    def generate(self, prompt: str) -> str:
        pass

class ConversationMemoryPort(ABC):
    @abstractmethod
    def add_turn(self, session_id: str, question: str, answer: str) -> None:
        pass

    @abstractmethod
    def get_history(self, session_id: str) -> List[MemoryTurn]:
        pass
