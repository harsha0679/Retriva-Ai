from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime
import uuid

class ChunkMetadata(BaseModel):
    """Metadata associated with every chunk of text."""
    filename: str
    chunk_id: str
    upload_timestamp: str
    document_id: str
    workspace_id: str = "default"
    version: int = 1
    status: str = "active"
    page_number: Optional[int] = None

class TextChunk(BaseModel):
    """Represents a single piece of text and its metadata."""
    text: str
    metadata: ChunkMetadata

class UploadResponse(BaseModel):
    """Response model for the /upload API endpoint."""
    status: str
    document_id: str
    filename: str
    total_chunks: int
    message: str
    workspace_id: str = "default"
    version: int = 1

# ── Phase 2 & 2.5 Models ──────────────────────────────────────────────────────

class ChatRequest(BaseModel):
    """Request body for POST /chat."""
    question: str
    session_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    document_id: Optional[str] = None
    workspace_id: Optional[str] = None

class RetrievedChunk(BaseModel):
    """A single chunk returned from the vector database search."""
    text: str
    metadata: Dict[str, Any]
    score: float
    document_id: Optional[str] = None
    filename: Optional[str] = None
    chunk_id: Optional[str] = None
    page_number: Optional[int] = None
    workspace_id: Optional[str] = None
    version: Optional[int] = None

class MemoryTurn(BaseModel):
    """One turn in a conversation."""
    question: str
    answer: str

# ── Phase 3: Observability ────────────────────────────────────────────────────

class RAGDebugInfo(BaseModel):
    """
    Structured observability data captured for every RAG request.
    Surfaces in the ChatResponse so the React debug panel can display it.
    Never includes API keys or secrets.
    """
    request_id: str
    retrieval_latency_ms: float
    llm_latency_ms: float
    total_latency_ms: float
    chunks_retrieved: int
    llm_provider: str
    model_name: str
    document_filter: Optional[str] = None
    workspace_filter: Optional[str] = None

class ChatResponse(BaseModel):
    """Full response returned by POST /chat."""
    answer: str
    session_id: str
    sources: List[RetrievedChunk]
    total_sources: int
    debug: Optional[RAGDebugInfo] = None

class DocumentSummary(BaseModel):
    """Summary of a document stored in the Vector DB."""
    document_id: str
    filename: str
    workspace_id: str = "default"
    version: int = 1
    status: str = "active"
    chunk_count: int
    upload_timestamp: str = ""

class DeleteDocumentResponse(BaseModel):
    """Response for DELETE /documents/{document_id}."""
    status: str
    document_id: str
    deleted_chunks: int
    message: str

class DeleteAllResponse(BaseModel):
    """Response for DELETE /documents (delete all)."""
    status: str
    deleted_documents: int
    deleted_chunks: int
    message: str

class HealthResponse(BaseModel):
    """System health status."""
    api: str
    vector_db: str
    llm: str
    phase: str = "3"
