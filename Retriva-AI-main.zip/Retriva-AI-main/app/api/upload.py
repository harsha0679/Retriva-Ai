import logging
from fastapi import APIRouter, UploadFile, File, Form, HTTPException
from app.domain.models import UploadResponse
from app.services.ingestion import KnowledgeIngestionService

logger = logging.getLogger(__name__)
router = APIRouter()


@router.post("/upload", response_model=UploadResponse)
def upload_document(
    file: UploadFile = File(...),
    workspace_id: str = Form("default"),
    version: int = Form(1)
):
    """
    Upload a document and ingest it into the RAG pipeline.
    Plain synchronous def — FastAPI runs this in its internal thread pool automatically.
    """
    try:
        content = file.file.read()
        filename = file.filename

        svc = KnowledgeIngestionService()
        result = svc.process_file(content, filename, workspace_id, version)

        if result["status"] == "error":
            raise HTTPException(status_code=400, detail=result["message"])

        return UploadResponse(**result)

    except HTTPException:
        raise
    except ValueError as ve:
        logger.error(f"Upload ValueError: {ve}")
        raise HTTPException(status_code=400, detail=str(ve))
    except Exception as e:
        logger.error(f"Upload error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"An error occurred during ingestion: {str(e)}")
