import logging
from typing import List, Optional
from fastapi import APIRouter, HTTPException, Query, Path
from app.services.document import DocumentService
from app.domain.models import DocumentSummary, DeleteDocumentResponse, DeleteAllResponse

logger = logging.getLogger(__name__)
router = APIRouter()
_document_service = None

def get_document_service() -> DocumentService:
    global _document_service
    if _document_service is None:
        _document_service = DocumentService()
    return _document_service

@router.get("/documents", response_model=List[DocumentSummary])
def list_documents(workspace_id: Optional[str] = Query(None)):
    """List all documents in the Vector Database."""
    try:
        service = get_document_service()
        return service.list_documents(workspace_id=workspace_id)
    except Exception as e:
        logger.error(f"Error listing documents: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to list documents: {str(e)}")

@router.delete("/documents", response_model=DeleteAllResponse)
def delete_all_documents():
    """
    DELETE /documents — Delete ALL indexed documents from the Vector Database.
    This is a destructive action. The React UI requires explicit user confirmation before calling this.
    """
    try:
        service = get_document_service()
        return service.delete_all()
    except Exception as e:
        logger.error(f"Error in delete-all: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to delete all documents: {str(e)}")

@router.delete("/documents/{document_id}", response_model=DeleteDocumentResponse)
def delete_document(document_id: str = Path(...)):
    """DELETE /documents/{document_id} — Delete ONLY one specific document."""
    try:
        service = get_document_service()
        res = service.delete_document(document_id=document_id)
        if res.status == "not_found":
            raise HTTPException(status_code=404, detail=res.message)
        return res
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting document {document_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to delete document: {str(e)}")
