import logging
from fastapi import APIRouter, HTTPException
from app.domain.models import ChatRequest, ChatResponse
from app.services.chat import ChatService

logger = logging.getLogger(__name__)
router = APIRouter()


@router.post("/chat", response_model=ChatResponse)
def chat(request: ChatRequest):
    """
    POST /chat — RAG pipeline endpoint.
    Plain synchronous def — FastAPI runs this in its internal thread pool automatically.
    """
    try:
        svc = ChatService()
        response = svc.chat(request)
        return response

    except ValueError as ve:
        logger.error(f"Configuration error: {ve}")
        raise HTTPException(status_code=500, detail=str(ve))
    except Exception as e:
        logger.error(f"Chat pipeline error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"An error occurred during generation: {str(e)}")
