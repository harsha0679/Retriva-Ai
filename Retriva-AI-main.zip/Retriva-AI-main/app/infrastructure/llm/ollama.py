# This file is intentionally left empty.
# The Ollama provider is implemented in: app/infrastructure/llm/ollama_provider.py
# It is registered in: app/infrastructure/llm/factory.py
