import logging
from ollama import Client
from app.domain.ports import LLMProviderPort
from app.core.config import settings

logger = logging.getLogger(__name__)

class OllamaProvider(LLMProviderPort):
    """
    Concrete implementation of LLMProviderPort using Ollama (local LLMs).

    Why it exists: To allow running the entire RAG pipeline 100% locally —
      no API keys, no internet, no cost per token.
    What problem it solves: Users can run open-source models (llama3, mistral,
      qwen, deepseek, etc.) via Ollama without changing any other code.
    How it connects to Phase 1/2: Plugs into LLMFactory exactly like GeminiProvider.
      ChatService never knows which LLM it's talking to.

    Prerequisites:
        1. Install Ollama: https://ollama.ai
        2. Pull a model: `ollama pull llama3.2`
        3. Set in .env:
               LLM_PROVIDER=ollama
               LLM_MODEL=llama3.2
               OLLAMA_BASE_URL=http://localhost:11434
    """
    def __init__(self):
        self.model = settings.LLM_MODEL
        self.client = Client(host=settings.OLLAMA_BASE_URL)
        logger.info(
            f"OllamaProvider initialized — model: '{self.model}' "
            f"at {settings.OLLAMA_BASE_URL}"
        )
        # Verify the model is available on the local Ollama server
        self._verify_model()

    def _verify_model(self) -> None:
        """Check that Ollama is running and the configured model is available. Start/pull automatically if needed."""
        import subprocess
        import time
        import urllib.request
        from urllib.error import URLError

        # 1. Check if Ollama server is running, if not, start it
        try:
            urllib.request.urlopen(settings.OLLAMA_BASE_URL, timeout=2.0)
        except URLError:
            logger.warning("Ollama server is not running. Starting it automatically in the background...")
            try:
                # Start ollama serve in the background without blocking
                subprocess.Popen(
                    ["ollama", "serve"], 
                    stdout=subprocess.DEVNULL, 
                    stderr=subprocess.DEVNULL,
                    creationflags=subprocess.CREATE_NO_WINDOW | subprocess.DETACHED_PROCESS
                )
                time.sleep(3)  # Give it a few seconds to initialize
                logger.info("Ollama server started successfully.")
            except Exception as e:
                logger.error(f"Failed to start Ollama automatically: {e}")
                return

        # 2. Check if the model is available, if not, pull it
        try:
            available = [m.model for m in self.client.list().models]
            # Normalize: Ollama may append ':latest' to model names
            normalized = [m.split(":")[0] for m in available]
            model_base = self.model.split(":")[0]
            
            if model_base not in normalized:
                logger.warning(f"Model '{self.model}' not found in Ollama. Pulling it automatically... This may take a few minutes.")
                try:
                    subprocess.run(["ollama", "pull", self.model], check=True)
                    logger.info(f"Successfully pulled model: {self.model}")
                except subprocess.CalledProcessError as e:
                    logger.error(f"Failed to pull model {self.model}: {e}")
        except Exception as e:
            logger.warning(f"Could not verify Ollama model availability: {e}")

    def generate(self, prompt: str) -> str:
        """
        Send the prompt to Ollama and return the response text.

        Uses the chat API so the prompt is sent as a single user message.
        This is compatible with all instruction-tuned models in Ollama.
        """
        try:
            response = self.client.chat(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                options={"temperature": settings.TEMPERATURE}
            )
            return response.message.content
        except Exception as e:
            logger.error(f"Ollama generation failed: {e}")
            raise
