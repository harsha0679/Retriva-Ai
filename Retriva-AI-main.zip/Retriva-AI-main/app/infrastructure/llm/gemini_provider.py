import logging
# pyrefly: ignore [missing-import]
import google.generativeai as genai
from app.domain.ports import LLMProviderPort
from app.core.config import settings

logger = logging.getLogger(__name__)

class GeminiProvider(LLMProviderPort):
    """
    Concrete implementation of LLMProviderPort using Google Gemini.

    Why it exists: To isolate the google-generativeai SDK from the rest of the application.
    What problem it solves: The GenerationService never knows it is talking to Gemini.
      If we want to switch to OpenAI tomorrow, we only create a new provider file — nothing else changes.
    How it connects to Phase 1: Uses the same Config pattern (settings.LLM_MODEL, settings.GEMINI_API_KEY).
    """
    def __init__(self):
        if not settings.GEMINI_API_KEY or settings.GEMINI_API_KEY == "your_gemini_api_key_here":
            raise ValueError(
                "GEMINI_API_KEY is not set. "
                "Please add your key to the .env file. "
                "Get one free at: https://aistudio.google.com/apikey"
            )
        genai.configure(api_key=settings.GEMINI_API_KEY)
        self.model = genai.GenerativeModel(
            model_name=settings.LLM_MODEL,
            generation_config=genai.GenerationConfig(
                temperature=settings.TEMPERATURE,
            )
        )
        logger.info(f"GeminiProvider initialized with model: {settings.LLM_MODEL}")

    def generate(self, prompt: str) -> str:
        """
        Send a prompt to Gemini and return the response text.
        Designed to be streaming-ready: switching to stream=True is trivial here.
        """
        try:
            response = self.model.generate_content(prompt)
            return response.text
        except Exception as e:
            logger.error(f"Gemini generation failed: {e}")
            raise
