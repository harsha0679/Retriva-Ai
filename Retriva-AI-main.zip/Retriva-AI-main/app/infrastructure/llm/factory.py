from app.domain.ports import LLMProviderPort
from app.core.config import settings

class LLMFactory:
    """
    Factory to instantiate the correct LLM provider based on configuration.

    Why it exists: To ensure no service ever directly imports a specific LLM SDK.
    What problem it solves: Switching between Ollama, Gemini, OpenAI, etc. requires
      only a one-line change in the .env file (LLM_PROVIDER=ollama).
    How it connects to Phase 1: Follows the exact same factory pattern as EmbeddingFactory and VectorDBFactory.

    Supported providers:
        - 'ollama'   → OllamaProvider  (local, uses local Ollama models like gemma3:1b)
        - 'gemini'   → GeminiProvider  (cloud, requires GEMINI_API_KEY)
    """
    _provider: LLMProviderPort = None

    @classmethod
    def get_provider(cls) -> LLMProviderPort:
        if cls._provider is not None:
            return cls._provider
            
        provider_name = settings.LLM_PROVIDER.lower()

        if provider_name == "ollama":
            from app.infrastructure.llm.ollama_provider import OllamaProvider
            cls._provider = OllamaProvider()

        elif provider_name == "gemini":
            from app.infrastructure.llm.gemini_provider import GeminiProvider
            cls._provider = GeminiProvider()

        else:
            raise ValueError(
                f"Unknown LLM provider: '{provider_name}'. "
                f"Supported: 'ollama', 'gemini'. Check LLM_PROVIDER in .env"
            )
            
        return cls._provider
