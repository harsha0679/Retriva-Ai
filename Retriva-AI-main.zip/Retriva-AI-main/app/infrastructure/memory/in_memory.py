from collections import defaultdict
from typing import List
from app.domain.ports import ConversationMemoryPort
from app.domain.models import MemoryTurn

class InMemoryConversationMemory(ConversationMemoryPort):
    """
    Simple in-memory conversation history store using a plain Python dict.

    Why it exists: To store past turns of a conversation so the LLM has context.
    What problem it solves: Without memory, every question to the LLM is stateless — 
      it forgets what was asked before. This class maintains that history per session.
    Why we separated it: Memory is an infrastructure concern. The ChatService only depends 
      on ConversationMemoryPort (the abstract interface), not on this class directly. 
      In Phase 3, this can be swapped for a Redis-backed implementation with zero 
      changes to any service.

    Trade-off: Data lives only as long as the server process. Restarting the server 
      clears all conversation history. This is acceptable for Phase 2.
    """
    # Class-level store shared across all instances (singleton behavior)
    _store: dict = defaultdict(list)

    def add_turn(self, session_id: str, question: str, answer: str) -> None:
        """Append a user/assistant turn to the session's history."""
        self._store[session_id].append(
            MemoryTurn(question=question, answer=answer)
        )

    def get_history(self, session_id: str) -> List[MemoryTurn]:
        """Return all past turns for the given session, oldest first."""
        return list(self._store[session_id])
