from app.domain.ports import ConversationMemoryPort
from app.core.config import settings

class MemoryFactory:
    """
    Factory to instantiate the correct conversation memory provider.

    Why it exists: To keep memory infrastructure swappable without touching service code.
    What problem it solves: Switching from in-memory to Redis in Phase 3 is just a 
      new provider + a one-line change in .env (MEMORY_PROVIDER=redis).

    Future providers to add here:
        - 'redis'    → RedisConversationMemory
        - 'postgres' → PostgresConversationMemory
    """
    @staticmethod
    def get_provider() -> ConversationMemoryPort:
        provider_name = settings.MEMORY_PROVIDER.lower()
        if provider_name == "in_memory":
            from app.infrastructure.memory.in_memory import InMemoryConversationMemory
            return InMemoryConversationMemory()
        else:
            raise ValueError(f"Unknown memory provider: '{provider_name}'. Check MEMORY_PROVIDER in .env")
