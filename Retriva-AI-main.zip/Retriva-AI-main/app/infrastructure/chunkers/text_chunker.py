import re
import uuid
from typing import List, Optional, Tuple
from app.domain.ports import TextChunkerPort
from app.domain.models import TextChunk, ChunkMetadata
from app.core.config import settings

# Regex patterns that indicate a heading/section title line
_HEADING_PATTERNS = [
    re.compile(r'^#{1,6}\s+'),                          # Markdown headings: ## Title
    re.compile(r'^[A-Z][A-Z0-9 :&/-]{3,}\s*$'),        # ALL-CAPS HEADINGS
    re.compile(r'^\d+\.\s+[A-Z]'),                      # Numbered: "1. Section Name"
    re.compile(r'^(SECTION|CHAPTER|PART)\s+\d+', re.I), # SECTION 1 / CHAPTER 2
    re.compile(r'^[-=]{3,}\s*$'),                        # Divider lines --- or ===
]

def _is_heading(line: str) -> bool:
    """Return True if a line looks like a section heading."""
    line = line.strip()
    if not line or len(line) > 120:
        return False
    return any(p.match(line) for p in _HEADING_PATTERNS)


class RecursiveTextChunker(TextChunkerPort):
    """
    Section-Context-Aware Recursive Text Chunker.

    Improvements over baseline:
    1. Detects section headings and attaches them as context prefix to every
       child chunk — so each chunk is self-contained and semantically anchored.
    2. Processes all pages as a single flow, carrying overlap text across page
       boundaries so no sentence is lost at a page break.
    3. Splits hierarchically: paragraphs → sentences → words.
    """

    # ─────────────────────────────────────────────────────────────
    # Public API
    # ─────────────────────────────────────────────────────────────

    def chunk(
        self,
        text: str,
        filename: str,
        document_id: str,
        upload_timestamp: str,
        workspace_id: str = "default",
        version: int = 1,
        status: str = "active",
        page_number: Optional[int] = None
    ) -> List[TextChunk]:
        if not text or not text.strip():
            return []
        pages = [(text, page_number)]
        return self.chunk_pages(
            pages=pages,
            filename=filename,
            document_id=document_id,
            upload_timestamp=upload_timestamp,
            workspace_id=workspace_id,
            version=version,
            status=status,
        )

    def chunk_pages(
        self,
        pages: List[Tuple[str, Optional[int]]],
        filename: str,
        document_id: str,
        upload_timestamp: str,
        workspace_id: str = "default",
        version: int = 1,
        status: str = "active",
    ) -> List[TextChunk]:
        """
        Process all pages as a single stream, preserving context across
        page boundaries via cross-page overlap.
        """
        # Merge all pages into a flat list of (line, page_number) tuples
        all_lines: List[Tuple[str, Optional[int]]] = []
        doc_header_lines = []
        
        for page_text, page_num in pages:
            if not page_text or not page_text.strip():
                continue
            for line in page_text.splitlines():
                stripped = line.strip()
                if stripped:
                    if len(doc_header_lines) < 3 and len(" ".join(doc_header_lines)) < 200:
                        doc_header_lines.append(stripped)
                all_lines.append((line, page_num))

        document_header = " ".join(doc_header_lines)

        return self._chunk_lines(
            all_lines=all_lines,
            document_header=document_header,
            filename=filename,
            document_id=document_id,
            upload_timestamp=upload_timestamp,
            workspace_id=workspace_id,
            version=version,
            status=status,
        )

    # ─────────────────────────────────────────────────────────────
    # Internal chunking logic
    # ─────────────────────────────────────────────────────────────

    def _chunk_lines(
        self,
        all_lines: List[Tuple[str, Optional[int]]],
        document_header: str,
        filename: str,
        document_id: str,
        upload_timestamp: str,
        workspace_id: str,
        version: int,
        status: str,
    ) -> List[TextChunk]:
        target_size = settings.CHUNK_SIZE
        target_overlap = settings.CHUNK_OVERLAP

        chunks: List[TextChunk] = []

        # Rolling state
        current_heading: str = ""          # Most recent section heading seen
        current_lines: List[str] = []      # Lines accumulating into current chunk
        current_page: Optional[int] = None # Page number of chunk start
        current_len: int = 0

        def flush(overlap_lines: List[str], next_page: Optional[int]) -> List[str]:
            """Save current buffer as a chunk. Return overlap tail for next chunk."""
            nonlocal current_heading
            if not current_lines:
                return []

            body = "\n".join(current_lines).strip()
            if not body:
                return []

            # Prefix chunk with Document Header AND Section Heading for deep semantic anchoring
            prefix_parts = []
            if document_header:
                prefix_parts.append(f"[Document Context: {document_header}]")
            if current_heading and not body.startswith(current_heading):
                prefix_parts.append(current_heading)
                
            prefix = "\n".join(prefix_parts)
            if prefix:
                chunk_text = f"{prefix}\n{body}"
            else:
                chunk_text = body

            chunk_id = str(uuid.uuid4())
            meta = ChunkMetadata(
                filename=filename,
                chunk_id=chunk_id,
                upload_timestamp=upload_timestamp,
                document_id=document_id,
                workspace_id=workspace_id,
                version=version,
                status=status,
                page_number=current_page,
            )
            chunks.append(TextChunk(text=chunk_text, metadata=meta))

            # Build overlap window from tail of current buffer
            tail: List[str] = []
            tail_len = 0
            for line in reversed(current_lines):
                if tail_len + len(line) + 1 <= target_overlap:
                    tail.insert(0, line)
                    tail_len += len(line) + 1
                else:
                    break
            return tail

        for raw_line, page_num in all_lines:
            line = raw_line.rstrip()

            # ── Detect section headings ─────────────────────────
            if _is_heading(line):
                # Flush what we have before starting new section
                if current_lines:
                    overlap = flush(current_lines, page_num)
                    current_lines = overlap
                    current_len = sum(len(l) + 1 for l in overlap)
                    current_page = page_num

                current_heading = line.strip()
                # Include heading as first line of new chunk
                if line.strip():
                    current_lines.append(line.strip())
                    current_len += len(line.strip()) + 1
                    if current_page is None:
                        current_page = page_num
                continue

            # ── Skip blank lines but use as soft paragraph boundary ──
            if not line.strip():
                if current_len >= target_size * 0.5:
                    overlap = flush(current_lines, page_num)
                    current_lines = overlap
                    current_len = sum(len(l) + 1 for l in overlap)
                    current_page = page_num if not overlap else current_page
                continue

            # ── Split oversized single lines at sentence boundaries ──
            sub_sentences = self._split_sentence(line.strip())
            for sentence in sub_sentences:
                if not sentence:
                    continue

                if current_page is None:
                    current_page = page_num

                if current_len + len(sentence) + 1 > target_size and current_lines:
                    overlap = flush(current_lines, page_num)
                    current_lines = overlap
                    current_len = sum(len(l) + 1 for l in overlap)
                    current_page = page_num

                current_lines.append(sentence)
                current_len += len(sentence) + 1

        # Flush any remaining content
        if current_lines:
            flush(current_lines, None)

        return chunks

    def _split_sentence(self, text: str) -> List[str]:
        """
        Split a long line into sentence-level units.
        Returns the line as-is if it fits within chunk size.
        """
        if len(text) <= settings.CHUNK_SIZE:
            return [text]

        # Split on sentence-ending punctuation
        parts = re.split(r'(?<=[.!?])\s+', text)
        result = []
        buf = ""
        for part in parts:
            if len(buf) + len(part) + 1 <= settings.CHUNK_SIZE:
                buf = f"{buf} {part}".strip()
            else:
                if buf:
                    result.append(buf)
                buf = part
        if buf:
            result.append(buf)
        return result if result else [text]


# Backward-compatibility alias
SimpleTextChunker = RecursiveTextChunker
