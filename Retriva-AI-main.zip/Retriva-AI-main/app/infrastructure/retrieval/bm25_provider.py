import re
import difflib
from typing import List, Optional, Dict, Any, Set
from rank_bm25 import BM25Okapi
from app.domain.models import RetrievedChunk


class BM25Retriever:
    """
    In-Memory BM25 Sparse Keyword Retriever using rank-bm25.
    Consumes plain dicts from ChromaProvider.get_all_chunks() — no Pydantic parsing.
    Includes difflib fuzzy typo tolerance (e.g. 'expireance' → 'experience').
    """

    def __init__(self):
        self._chunks: List[Dict[str, Any]] = []
        self._corpus_tokens: List[List[str]] = []
        self._vocabulary: Set[str] = set()
        self.bm25: Optional[BM25Okapi] = None

    def _tokenize(self, text: str) -> List[str]:
        """Lowercase word tokenizer."""
        return [w.lower() for w in re.findall(r'\w+', text)]

    def index(self, chunks: List[Dict[str, Any]]):
        """
        Build BM25 index from a list of plain dicts.
        Each dict must have at least: text, document_id, workspace_id, chunk_id
        """
        self._chunks = list(chunks)
        self._corpus_tokens = [self._tokenize(c.get("text", "")) for c in self._chunks]
        self._vocabulary = {t for tokens in self._corpus_tokens for t in tokens}
        self.bm25 = BM25Okapi(self._corpus_tokens) if self._corpus_tokens else None

    def _fuzzy_correct(self, tokens: List[str]) -> List[str]:
        """Map typo tokens to nearest vocabulary word using difflib."""
        if not self._vocabulary:
            return tokens
        vocab = list(self._vocabulary)
        corrected = []
        for tok in tokens:
            if tok in self._vocabulary or len(tok) <= 3:
                corrected.append(tok)
            else:
                matches = difflib.get_close_matches(tok, vocab, n=1, cutoff=0.6)
                corrected.append(matches[0] if matches else tok)
        return corrected

    def normalize_query(self, query: str) -> str:
        """
        Return a typo-corrected version of the query using corpus vocabulary.
        e.g. 'what are the expireance' -> 'what are the experience'
        Used to show a clean question to the LLM even when input has typos.
        """
        tokens = self._tokenize(query)
        corrected = self._fuzzy_correct(tokens)
        return " ".join(corrected)

    def search(
        self,
        query: str,
        top_k: int = 10,
        document_id: Optional[str] = None,
        workspace_id: Optional[str] = None,
        min_score: float = 0.0,
    ) -> List[RetrievedChunk]:
        if not self.bm25 or not self._chunks:
            return []

        raw_tokens = self._tokenize(query)
        if not raw_tokens:
            return []

        query_tokens = self._fuzzy_correct(raw_tokens)
        scores = self.bm25.get_scores(query_tokens)

        scored = []
        for chunk_dict, score in zip(self._chunks, scores):
            if score <= min_score:
                continue
            doc_id_stored = chunk_dict.get("document_id", "")
            ws_id_stored = chunk_dict.get("workspace_id", "")
            if document_id and doc_id_stored != document_id:
                continue
            if workspace_id and ws_id_stored != workspace_id:
                continue
            scored.append((chunk_dict, float(score)))

        scored.sort(key=lambda x: x[1], reverse=True)

        results = []
        for chunk_dict, score in scored[:top_k]:
            results.append(RetrievedChunk(
                text=chunk_dict.get("text", ""),
                metadata={
                    "document_id": chunk_dict.get("document_id", ""),
                    "filename": chunk_dict.get("filename", ""),
                    "chunk_id": chunk_dict.get("chunk_id", ""),
                    "page_number": chunk_dict.get("page_number"),
                    "workspace_id": chunk_dict.get("workspace_id", "default"),
                },
                score=round(score, 4),
                document_id=chunk_dict.get("document_id", ""),
                filename=chunk_dict.get("filename", ""),
                chunk_id=chunk_dict.get("chunk_id", ""),
                page_number=chunk_dict.get("page_number"),
                workspace_id=chunk_dict.get("workspace_id", "default"),
            ))
        return results
