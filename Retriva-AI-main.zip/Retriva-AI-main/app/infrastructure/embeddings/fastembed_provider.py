from typing import List
from fastembed import TextEmbedding
from app.domain.ports import EmbeddingProviderPort
from app.core.config import settings
import logging

logger = logging.getLogger(__name__)

class FastEmbedProvider(EmbeddingProviderPort):
    """
    Concrete implementation of EmbeddingProviderPort using fastembed.
    Why it exists: To isolate the fastembed dependency and replace sentence-transformers.
    What problem it solves: Prevents PyTorch OpenMP crashes on Windows by using ONNX runtime,
    and provides significantly faster CPU embeddings.
    """
    def __init__(self):
        # Model is loaded once when the provider is instantiated
        logger.info(f"Loading FastEmbed model: {settings.MODEL_NAME}...")
        self.model = TextEmbedding(model_name=settings.MODEL_NAME)
        logger.info("FastEmbed model loaded successfully.")

    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        # fastembed returns a generator of numpy arrays, we convert to a list of lists of floats
        embeddings_generator = self.model.embed(texts)
        return [e.tolist() for e in embeddings_generator]
