from app.domain.ports import EmbeddingProviderPort
from app.infrastructure.embeddings.fastembed_provider import FastEmbedProvider
from app.core.config import settings

class EmbeddingFactory:
    """
    Factory to instantiate the correct embedding provider based on configuration.
    Why it exists: To avoid hardcoding a specific embedding implementation in the application logic.
    What problem it solves: Allows changing the embedding mechanism just by updating the .env file.
    """
    _provider: EmbeddingProviderPort = None

    @classmethod
    def get_provider(cls) -> EmbeddingProviderPort:
        if cls._provider is not None:
            return cls._provider
            
        provider_name = settings.EMBEDDING_PROVIDER.lower()
        if provider_name == "fastembed":
            cls._provider = FastEmbedProvider()
        # Future providers like 'openai' or 'gemini' would be added here
        else:
            raise ValueError(f"Unknown embedding provider: {provider_name}")
            
        return cls._provider
