import io
from typing import List, Tuple, Optional
import docx
from app.domain.ports import DocumentLoaderPort

try:
    import pymupdf as fitz  # PyMuPDF
    HAS_FITZ = True
except ImportError:
    HAS_FITZ = False
    import PyPDF2

class SimpleDocumentLoader(DocumentLoaderPort):
    """
    Concrete implementation for extracting text from different file types.
    Uses PyMuPDF (fitz) for layout-aware PDF extraction (multi-column resumes & papers).
    """
    def load(self, file_content: bytes, filename: str) -> str:
        pages = self.load_pages(file_content, filename)
        return "\n\n".join(p_text for p_text, _ in pages if p_text.strip())

    def load_pages(self, file_content: bytes, filename: str) -> List[Tuple[str, Optional[int]]]:
        ext = filename.split('.')[-1].lower()
        if ext == 'pdf':
            return self._extract_pdf_pages(file_content)
        elif ext == 'docx':
            return self._extract_docx_pages(file_content)
        elif ext in ['txt', 'md']:
            text = file_content.decode('utf-8', errors='ignore')
            return [(text, None)]
        else:
            raise ValueError(f"Unsupported file format: {ext}")

    def _extract_pdf_pages(self, content: bytes) -> List[Tuple[str, Optional[int]]]:
        pages = []
        if HAS_FITZ:
            doc = fitz.open(stream=content, filetype="pdf")
            for i, page in enumerate(doc, start=1):
                # sort=True sorts text by reading order (top-down, left-right) for multi-column layouts
                page_text = page.get_text("text", sort=True) or ""
                if page_text.strip():
                    pages.append((page_text.strip(), i))
        else:
            pdf_reader = PyPDF2.PdfReader(io.BytesIO(content))
            for i, page in enumerate(pdf_reader.pages, start=1):
                page_text = page.extract_text() or ""
                if page_text.strip():
                    pages.append((page_text.strip(), i))

        if not pages:
            pages = [("", 1)]
        return pages
    
    def _extract_docx_pages(self, content: bytes) -> List[Tuple[str, Optional[int]]]:
        doc = docx.Document(io.BytesIO(content))
        text = "\n".join([para.text for para in doc.paragraphs if para.text.strip()])
        return [(text, None)]
