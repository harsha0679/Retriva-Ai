# pyrefly: ignore [missing-import]
import chromadb
from typing import List, Optional, Dict, Any
from app.domain.ports import VectorDBProviderPort
from app.domain.models import TextChunk, RetrievedChunk, DocumentSummary, ChunkMetadata
from app.core.config import settings

class ChromaProvider(VectorDBProviderPort):
    """ChromaDB implementation of VectorDBProviderPort."""
    def __init__(self):
        self.client = chromadb.PersistentClient(path="./chroma_db")
        self.collection = self.client.get_or_create_collection(
            name=settings.CHROMA_COLLECTION,
            metadata={"hnsw:space": "cosine"}
        )

    def store(self, chunks: List[TextChunk], embeddings: List[List[float]]):
        if not chunks:
            return
        ids = [chunk.metadata.chunk_id for chunk in chunks]
        documents = [chunk.text for chunk in chunks]
        metadatas = [chunk.metadata.model_dump(exclude_none=True) for chunk in chunks]
        self.collection.add(ids=ids, embeddings=embeddings, documents=documents, metadatas=metadatas)

    def search(
        self, query_embedding: List[float], top_k: int,
        document_id: Optional[str] = None, workspace_id: Optional[str] = None,
        threshold: Optional[float] = None
    ) -> List[RetrievedChunk]:
        min_threshold = threshold if threshold is not None else settings.SIMILARITY_THRESHOLD

        filters = [{"status": "active"}]
        if document_id:
            filters.append({"document_id": document_id})
        if workspace_id:
            filters.append({"workspace_id": workspace_id})
        where_clause = filters[0] if len(filters) == 1 else {"$and": filters}

        results = self.collection.query(
            query_embeddings=[query_embedding],
            n_results=top_k,
            where=where_clause,
            include=["documents", "metadatas", "distances"]
        )

        retrieved_chunks = []
        if not results or not results["ids"] or not results["ids"][0]:
            return retrieved_chunks

        # Inspect Chroma collection distance space (defaults to 'l2' on pre-existing collections)
        space = (self.collection.metadata or {}).get("hnsw:space", "l2")

        for doc, meta, distance in zip(results["documents"][0], results["metadatas"][0], results["distances"][0]):
            if space == "cosine":
                # Cosine distance: distance = 1 - cosine_similarity
                score = max(0.0, 1.0 - distance)
            else:
                # L2 distance for unit vectors: L2_squared = 2 - 2 * cosine_similarity
                score = max(0.0, 1.0 - (distance / 2.0))

            score = round(score, 4)

            if score < min_threshold:
                continue
            retrieved_chunks.append(RetrievedChunk(
                text=doc, metadata=meta, score=score,
                document_id=meta.get("document_id"), filename=meta.get("filename"),
                chunk_id=meta.get("chunk_id"), page_number=meta.get("page_number"),
                workspace_id=meta.get("workspace_id"), version=meta.get("version")
            ))
        return retrieved_chunks

    def delete_document(self, document_id: str) -> int:
        existing = self.collection.get(where={"document_id": document_id})
        chunk_count = len(existing["ids"]) if existing and "ids" in existing else 0
        if chunk_count > 0:
            self.collection.delete(where={"document_id": document_id})
        return chunk_count

    def delete_all(self) -> dict:
        """Delete ALL vectors from the collection by getting all IDs and deleting them."""
        existing = self.collection.get(include=[])
        all_ids = existing.get("ids", [])
        total_chunks = len(all_ids)

        # Count distinct document IDs before deletion
        meta_data = self.collection.get(include=["metadatas"])
        doc_ids = set()
        for meta in (meta_data.get("metadatas") or []):
            if meta and "document_id" in meta:
                doc_ids.add(meta["document_id"])
        total_documents = len(doc_ids)

        if total_chunks > 0:
            self.collection.delete(ids=all_ids)

        return {"documents": total_documents, "chunks": total_chunks}

    def list_documents(self, workspace_id: Optional[str] = None) -> List[DocumentSummary]:
        get_kwargs: Dict[str, Any] = {"include": ["metadatas"]}
        if workspace_id:
            get_kwargs["where"] = {"workspace_id": workspace_id}
        data = self.collection.get(**get_kwargs)
        if not data or not data["metadatas"]:
            return []
        doc_groups: Dict[str, Dict[str, Any]] = {}
        for meta in data["metadatas"]:
            doc_id = meta.get("document_id")
            if not doc_id:
                continue
            if doc_id not in doc_groups:
                doc_groups[doc_id] = {
                    "document_id": doc_id, "filename": meta.get("filename", "unknown"),
                    "workspace_id": meta.get("workspace_id", "default"),
                    "version": meta.get("version", 1), "status": meta.get("status", "active"),
                    "upload_timestamp": meta.get("upload_timestamp", ""), "chunk_count": 0
                }
            doc_groups[doc_id]["chunk_count"] += 1
        return [DocumentSummary(**info) for info in doc_groups.values()]

    def get_all_chunks(self) -> List[Dict[str, Any]]:
        """
        Retrieve all stored chunks as plain dicts for BM25 keyword indexing.
        Returns raw {text, document_id, workspace_id, chunk_id, filename, page_number}
        without going through Pydantic model reconstruction (avoids silent field errors).
        """
        data = self.collection.get(include=["documents", "metadatas"])
        if not data or not data.get("documents"):
            return []
        results = []
        for chunk_id, doc, meta in zip(
            data["ids"], data["documents"], data["metadatas"]
        ):
            if not doc or not meta:
                continue
            results.append({
                "text": doc,
                "chunk_id": chunk_id,
                "document_id": meta.get("document_id", ""),
                "workspace_id": meta.get("workspace_id", "default"),
                "filename": meta.get("filename", ""),
                "page_number": meta.get("page_number"),
            })
        return results

