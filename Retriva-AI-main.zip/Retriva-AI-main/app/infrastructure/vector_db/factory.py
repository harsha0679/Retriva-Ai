from app.domain.ports import VectorDBProviderPort
from app.infrastructure.vector_db.chroma_provider import ChromaProvider
from app.core.config import settings

class VectorDBFactory:
    """
    Factory to instantiate the correct vector db provider based on configuration.
    Why it exists: To avoid hardcoding a specific Vector DB implementation.
    What problem it solves: Allows changing the database just by updating the .env file.
    """
    _provider: VectorDBProviderPort = None

    @classmethod
    def get_provider(cls) -> VectorDBProviderPort:
        if cls._provider is not None:
            return cls._provider
            
        db_name = settings.VECTOR_DB.lower()
        if db_name == "chroma":
            cls._provider = ChromaProvider()
        # Future providers like 'faiss' or 'pinecone' would be added here
        else:
            raise ValueError(f"Unknown vector db provider: {db_name}")
            
        return cls._provider
