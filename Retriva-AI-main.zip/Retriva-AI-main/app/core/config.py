from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    """
    Configuration settings for the application.
    This module exists to provide a single source of truth for configuration variables,
    loading them from the environment or a .env file, and performing type validation.
    """
    # --- Phase 1: Ingestion ---
    EMBEDDING_PROVIDER: str = "fastembed"
    VECTOR_DB: str = "chroma"
    MODEL_NAME: str = "BAAI/bge-small-en-v1.5"
    CHROMA_COLLECTION: str = "knowledge_base"
    CHUNK_SIZE: int = 700
    CHUNK_OVERLAP: int = 150

    # --- Phase 2: Retrieval & Generation ---
    LLM_PROVIDER: str = "ollama"
    LLM_MODEL: str = "qwen2.5:7b"
    OLLAMA_BASE_URL: str = "http://localhost:11434"
    OLLAMA_API_KEY: str = "ollama"
    TOP_K: int = 30
    RERANK_TOP_K: int = 5
    TEMPERATURE: float = 0.0
    MEMORY_PROVIDER: str = "in_memory"

    # --- Phase 2.5: Document Isolation & Quality ---
    SIMILARITY_THRESHOLD: float = 0.20
    DEFAULT_WORKSPACE: str = "default"

    # --- Hugging Face ---
    HF_TOKEN: str = ""

    class Config:
        env_file = ".env"

settings = Settings()
